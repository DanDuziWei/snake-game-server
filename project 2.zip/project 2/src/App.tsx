import React, { useEffect, useRef, useState, useCallback } from 'react';
import { TowerControl as GameController, Users, Copy } from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { WEBSOCKET_URL } from './config';

// 游戏常量
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const BLOCK_SIZE = 20;
const GAME_SPEED = 15;

// 颜色
const COLORS = {
  BLACK: '#000000',
  WHITE: '#FFFFFF',
  RED: '#FF0000',
  GREEN: '#00FF00',
  BLUE: '#0000FF',
  YELLOW: '#FFFF00',
  PURPLE: '#800080',
};

// 方向
const Direction = {
  UP: { x: 0, y: -1 },
  DOWN: { x: 0, y: 1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 },
} as const;

type Position = { x: number; y: number };
type FoodType = 'normal' | 'speed' | 'slow' | 'double' | 'shorter';

interface Food {
  position: Position;
  type: FoodType;
  color: string;
}

// WebSocket事件类型
type GameState = {
  snake1: Snake;
  snake2: Snake;
  food: Food;
  roomId: string;
};

type GameEvent = {
  type: 'direction' | 'start' | 'join';
  data: any;
};

class Snake {
  positions: Position[];
  direction: typeof Direction[keyof typeof Direction];
  color: string;
  score: number;
  speed: number;
  effectTimer: number;
  length: number;
  playerNum: number;

  constructor(startPos: Position, color: string, playerNum: number) {
    this.positions = [startPos];
    this.direction = Direction.RIGHT;
    this.color = color;
    this.score = 0;
    this.speed = GAME_SPEED;
    this.effectTimer = 0;
    this.length = 1;
    this.playerNum = playerNum;
  }

  reset() {
    const x = this.playerNum === 1 ? CANVAS_WIDTH / 4 : (CANVAS_WIDTH * 3) / 4;
    this.positions = [{ x, y: CANVAS_HEIGHT / 2 }];
    this.direction = Direction.RIGHT;
    this.score = 0;
    this.speed = GAME_SPEED;
    this.effectTimer = 0;
    this.length = 1;
  }

  update(): boolean {
    if (this.effectTimer > 0) {
      this.effectTimer--;
      if (this.effectTimer === 0) {
        this.speed = GAME_SPEED;
      }
    }

    const head = this.positions[0];
    const newHead = {
      x: (head.x + this.direction.x * BLOCK_SIZE + CANVAS_WIDTH) % CANVAS_WIDTH,
      y: (head.y + this.direction.y * BLOCK_SIZE + CANVAS_HEIGHT) % CANVAS_HEIGHT,
    };

    // 检查是否撞到自己
    if (this.positions.slice(3).some(p => p.x === newHead.x && p.y === newHead.y)) {
      return false;
    }

    this.positions.unshift(newHead);
    if (this.positions.length > this.length) {
      this.positions.pop();
    }
    return true;
  }
}

function generateFood(snake1: Snake, snake2: Snake): Food {
  const foodTypes: FoodType[] = ['normal', 'speed', 'slow', 'double', 'shorter'];
  const type = foodTypes[Math.floor(Math.random() * foodTypes.length)];
  
  const colors: Record<FoodType, string> = {
    normal: COLORS.RED,
    speed: COLORS.BLUE,
    slow: COLORS.YELLOW,
    double: COLORS.PURPLE,
    shorter: COLORS.GREEN,
  };

  let position: Position;
  do {
    position = {
      x: Math.floor(Math.random() * (CANVAS_WIDTH / BLOCK_SIZE)) * BLOCK_SIZE,
      y: Math.floor(Math.random() * (CANVAS_HEIGHT / BLOCK_SIZE)) * BLOCK_SIZE,
    };
  } while (
    snake1.positions.some(p => p.x === position.x && p.y === position.y) ||
    snake2.positions.some(p => p.x === position.x && p.y === position.y)
  );

  return { position, type, color: colors[type] };
}

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState<string>('');
  const [isHost, setIsHost] = useState(false);
  const [copied, setCopied] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const [error, setError] = useState<string>('');
  
  // 连接WebSocket服务器
  useEffect(() => {
    const newSocket = io(WEBSOCKET_URL, {
      transports: ['websocket'],
      reconnection: false,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000
    });
    
    newSocket.on('connect', () => {
      console.log('Successfully connected to server:', WEBSOCKET_URL);
      setError(''); // 清除之前的错误信息
    });
    
    newSocket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error);
      console.error('Connection details:', {
        url: WEBSOCKET_URL,
        error: error.message,
        type: error.type
      });
      setError(`连接服务器失败: ${error.message}`);
    });
    
    newSocket.on('disconnect', (reason) => {
      console.log('Disconnected:', reason);
      setError(`与服务器断开连接: ${reason}`);
    });
    
    newSocket.on('gameState', (state: GameState) => {
      console.log('Received game state:', state);
      // 更新游戏状态
      if (canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          drawGame(ctx, state);
        }
      }
    });
    
    newSocket.on('roomCreated', (id: string) => {
      setRoomId(id);
      setIsHost(true);
      setWaiting(true);
    });
    
    newSocket.on('roomJoined', () => {
      setGameStarted(true);
      setWaiting(false);
    });
    
    newSocket.on('error', (msg: string) => {
      setError(msg);
    });
    
    setSocket(newSocket);
    
    return () => {
      newSocket.disconnect();
    };
  }, []);
  
  const createRoom = useCallback(() => {
    if (socket) {
      socket.emit('createRoom');
    }
  }, [socket]);
  
  const joinRoom = useCallback((id: string) => {
    if (socket) {
      socket.emit('joinRoom', id);
    }
  }, [socket]);
  
  const copyRoomId = useCallback(() => {
    navigator.clipboard.writeText(roomId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [roomId]);
  
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (!socket || !gameStarted) return;
    
    const direction = {
      ArrowUp: Direction.UP,
      ArrowDown: Direction.DOWN,
      ArrowLeft: Direction.LEFT,
      ArrowRight: Direction.RIGHT,
      w: Direction.UP,
      s: Direction.DOWN,
      a: Direction.LEFT,
      d: Direction.RIGHT,
    }[e.key];
    
    if (direction) {
      socket.emit('direction', direction);
    }
  }, [socket, gameStarted]);
  
  useEffect(() => {
    if (!gameStarted || !socket) return;
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [gameStarted, socket, handleKeyDown]);

  function drawGame(ctx: CanvasRenderingContext2D, state: GameState) {
    // 清空画布
    ctx.fillStyle = COLORS.BLACK;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // 绘制蛇
    function drawSnake(snake: Snake) {
      ctx.fillStyle = snake.color;
      snake.positions.forEach(pos => {
        ctx.fillRect(pos.x, pos.y, BLOCK_SIZE, BLOCK_SIZE);
      });
    }

    drawSnake(state.snake1);
    drawSnake(state.snake2);

    // 绘制食物
    ctx.fillStyle = state.food.color;
    ctx.fillRect(state.food.position.x, state.food.position.y, BLOCK_SIZE, BLOCK_SIZE);

    // 绘制分数
    ctx.fillStyle = COLORS.WHITE;
    ctx.font = '24px Arial';
    ctx.fillText(`玩家1得分: ${state.snake1.score}`, 10, 30);
    ctx.fillText(`玩家2得分: ${state.snake2.score}`, 10, 60);
  }

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
      {error && (
        <div className="bg-red-500 text-white px-4 py-2 rounded-lg mb-4">
          {error}
        </div>
      )}
      
      {!gameStarted ? (
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-8">在线双人贪食蛇</h1>
          
          {!waiting ? (
            <div className="space-y-6">
              <div className="space-y-4 text-gray-300 mb-8">
                <p>创建房间或加入好友的房间</p>
              </div>
              
              <div className="flex flex-col space-y-4">
                <button
                  onClick={createRoom}
                  className="flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg transition-colors"
                >
                  <GameController className="w-6 h-6" />
                  <span>创建房间</span>
                </button>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    placeholder="输入房间ID"
                    value={roomId}
                    onChange={(e) => setRoomId(e.target.value)}
                    className="bg-gray-800 text-white px-4 py-2 rounded-lg flex-1"
                  />
                  <button
                    onClick={() => joinRoom(roomId)}
                    className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
                  >
                    <Users className="w-5 h-5" />
                    <span>加入</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <p className="text-gray-300">等待玩家加入...</p>
              <div className="flex items-center justify-center space-x-2">
                <input
                  type="text"
                  value={roomId}
                  readOnly
                  className="bg-gray-800 text-white px-4 py-2 rounded-lg"
                />
                <button
                  onClick={copyRoomId}
                  className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  <Copy className="w-5 h-5" />
                  <span>{copied ? '已复制' : '复制'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <canvas
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="border-4 border-gray-700 rounded-lg"
        />
      )}
    </div>
  );
}

export default App;