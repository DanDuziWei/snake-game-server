// 开发环境使用 localhost，生产环境使用实际的后端地址
export const WEBSOCKET_URL = import.meta.env.PROD 
  ? 'wss://snake-game-server-s4fu.onrender.com'
  : 'ws://localhost:3001';

// 添加调试日志
console.log('WebSocket URL:', WEBSOCKET_URL);
console.log('Environment:', import.meta.env.PROD ? 'production' : 'development');